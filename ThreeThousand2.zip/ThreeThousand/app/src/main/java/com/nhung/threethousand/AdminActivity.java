package com.nhung.threethousand;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.*;

public class AdminActivity extends Activity
{
	Button btnAddFull,btnAddAudio,btnAddLanguage,btnAddMeans,btnAddAvatar;
	ListView listView;
	@Override
	public void onCreate (Bundle saveInstanceState){
		super.onCreate(saveInstanceState);
		setContentView(R.layout.admin);
		btnAddFull = (Button)findViewById(R.id.btnAddFull);
		btnAddAudio = (Button)findViewById(R.id.btnAddAudio);
		btnAddLanguage = (Button)findViewById(R.id.btnAddLanguage);
		btnAddMeans = (Button)findViewById(R.id.btnAddMeans);
		btnAddAvatar = (Button)findViewById(R.id.btnAddAvatar);
		listView = (ListView)findViewById(R.id.listView);
		
		btnAddFull.setOnClickListener(new View.OnClickListener(){
			public void onClick (View v){
				startActivity (new Intent(AdminActivity.this,AddFullWordActivity.class));
			}
			});
		btnAddAudio.setOnClickListener(new View.OnClickListener(){
				public void onClick (View v){
					
				}
			});
		btnAddLanguage.setOnClickListener(new View.OnClickListener(){
				public void onClick (View v){
					startActivity(new Intent(AdminActivity.this,LanguageActivity.class));
				}
			});
		btnAddMeans.setOnClickListener(new View.OnClickListener(){
				public void onClick (View v){

				}
			});
		btnAddAvatar
		.setOnClickListener(new View.OnClickListener(){
				public void onClick (View v){

				}
			});
		
	}
	
}
