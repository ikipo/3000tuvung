package com.nhung.threethousand;
import android.os.*;
import android.app.*;
import android.widget.*;
import com.nhung.threethousand.Adapter.*;
import com.nhung.threethousand.Entities.*;
import com.nhung.threethousand.Database.*;
import java.util.*;
import android.view.*;

public class BookmarkActivity extends Activity
{
	ProgressDialog progressDialog;
	ListView lv;
	List <FullWord> list;
	public void onCreate(Bundle saveInstanceState){
		super.onCreate(saveInstanceState);
		setContentView(R.layout.main);
		progressDialog = new ProgressDialog(this);
		lv = (ListView)findViewById(R.id.listWords);	
		new Data ().execute();
	}
	public void showProgressDialog() {
		if (progressDialog == null) {
			progressDialog = new ProgressDialog(BookmarkActivity.this);
			progressDialog.setIndeterminate(true);
			progressDialog.setCancelable(false);
		}
		progressDialog.setMessage("Loading ...");
		progressDialog.show();	
	}

	public void dismissProgressDialog() {
		if (progressDialog != null ) {
			progressDialog.dismiss();
		}
	}
	private class Data extends AsyncTask <Void,Void,Void>
	{

		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			showProgressDialog();
		}

		@Override
		protected Void doInBackground(Void[] p1)
		{
			list = new WordDAO(BookmarkActivity.this).getBookmark(BookmarkActivity.this);
			// TODO: Implement this method
			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			WordAdapter adapter = new WordAdapter(BookmarkActivity.this,list);
			lv.setAdapter(adapter);
			dismissProgressDialog();
		}

		
	}
}
