package com.nhung.threethousand.Database;
import android.content.*;
import android.database.sqlite.*;
import android.database.*;

public class AdminDAO extends Database{
	public AdminDAO(Context c){
		super(c);
		add();
	}
	public void add(){
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("id","admin");
		values.put("password","123");
		values.put("idlanguage","vn");
		db.insert("Admin",null,values);
		db.close();
	}
	public String getIdLang(){
		String s = "";
		SQLiteDatabase db = getReadableDatabase();
		String sql = "select * from Admin";
		Cursor c = db.rawQuery(sql,null);
		if(c!=null){
			c.moveToFirst();
			do{
				String id = c.getString(0);
				String password = c.getString(1);
				String idlanguage = c.getString(2);
				s = idlanguage;
			}while(c.moveToNext());
		}
		return s;
	}
	public void setLanguage(String idlanguage){
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("idlanguage",idlanguage);
		db.update("Admin",values,"id like 'admin'",null);
		db.close();
	}
}
