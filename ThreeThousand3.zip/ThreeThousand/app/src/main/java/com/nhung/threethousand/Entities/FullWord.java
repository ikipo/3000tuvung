package com.nhung.threethousand.Entities;
import java.io.*;

public class FullWord implements Serializable
{
	private String id, spelling, means, audio;
	
	public FullWord(){
		
	}

	public FullWord(String id, String spelling, String means, String audio)
	{
		this.id = id;
		this.spelling = spelling;
		this.means = means;
		this.audio = audio;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getId()
	{
		return id;
	}

	public void setSpelling(String spelling)
	{
		this.spelling = spelling;
	}

	public String getSpelling()
	{
		return spelling;
	}

	public void setMeans(String means)
	{
		this.means = means;
	}

	public String getMeans()
	{
		return means;
	}

	public void setAudio(String audio)
	{
		this.audio = audio;
	}

	public String getAudio()
	{
		return audio;
	}
}
