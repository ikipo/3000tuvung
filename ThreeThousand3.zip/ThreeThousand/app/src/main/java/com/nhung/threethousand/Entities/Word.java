package com.nhung.threethousand.Entities;
import java.io.*;

public class Word implements Serializable
{
	private String id;
	private String spelling;
	private String audio;
	public Word (){
		this.id = "";
		this.spelling = "";
		this.audio = "";
	}
	public Word (String id){
		this.id = id;
	}
	
	public Word (String id, String spelling){
		this.id = id;
		this.spelling = spelling;
	}
	public Word (String id, String spelling, String audio){
		this.id = id;
		this.spelling = spelling;
		this.audio = audio;
	}

	public void setSpelling(String spelling)
	{
		this.spelling = spelling;
	}

	public String getSpelling()
	{
		return spelling;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getId()
	{
		return id;
	}

	public void setAudio(String audio)
	{
		this.audio = audio;
	}

	public String getAudio()
	{
		return audio;
	}
	
}
