package com.nhung.threethousand;

import android.app.*;
import android.os.*;
import android.content.Context;
import android.widget.*;
import com.nhung.threethousand.Entities.*;
import com.nhung.threethousand.Database.*;
import java.util.*;
import android.view.*;
import com.nhung.threethousand.Adapter.*;
import android.content.*;
import java.io.*;

public class MainActivity extends Activity 
{
	Button btnAdmin;
	List<FullWord> list;
	ListView listWords;
	ProgressDialog progressDialog;
	WordAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		list = new ArrayList <>();
		progressDialog = new ProgressDialog(MainActivity.this);
		listWords = (ListView)findViewById(R.id.listWords);
		btnAdmin = (Button)findViewById(R.id.btnAdmin);
		btnAdmin.setOnClickListener(new View.OnClickListener(){
				public void onClick (View v){
					startActivity (new Intent(MainActivity.this,AdminActivity.class));
				}
			});			
		boolean b = new WordDAO(this).checkTabledata();
		//if(b){
			new Data().execute();
		//}else{
			//addWords();
			//new AddWord().execute();
		//}
    }
	public void showProgressDialog() {
		if (progressDialog == null) {
			progressDialog = new ProgressDialog(MainActivity.this);
			progressDialog.setIndeterminate(true);
			progressDialog.setCancelable(false);
		}
		progressDialog.setMessage("Loading ...");
		progressDialog.show();	
	}
	
	public void dismissProgressDialog() {
		if (progressDialog != null ) {
			progressDialog.dismiss();
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// TODO: Implement this method
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO: Implement this method
		switch (item.getItemId()) {
			case R.id.refresh:
				finish();
				startActivity(getIntent());
				return true;
			case R.id.language:
				showLanguageDialog();
				return true;
			case R.id.bookmark:
				try{				
				startActivity(new Intent(MainActivity.this,BookmarkActivity.class));
				}catch(Exception e){
					Toast.makeText(this,"None word in Bookmark",Toast.LENGTH_LONG).show();
				} return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
	
	public void showLanguageDialog (){
		final Dialog dialog = new Dialog(this);
		dialog.setTitle("Your Language");
		View v = LayoutInflater.from(this).inflate(R.layout.menulanguage,null,false);
		dialog.setContentView(v);
		try{			    
			new AdminDAO(this).add();
			final ListView lv = (ListView)v.findViewById(R.id.menulanguageListView);			
			ArrayAdapter <String> adapter = new ArrayAdapter (this,android.R.layout.simple_expandable_list_item_1,new LanguageDAO(this).getAllId());
			lv.setAdapter(adapter);
	 		lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){
				public void onItemClick(AdapterView <?> p1, View p2, int p3, long p4){
					String id = lv.getItemAtPosition(p3).toString();
					new AdminDAO(MainActivity.this).setLanguage(id);
					dialog.dismiss();
					//String filemeans = new AdminDAO(MainActivity.this).getIdLang()+".txt";
					//addMeans(filemeans);
					//Toast.makeText(MainActivity.this,filemeans,Toast.LENGTH_SHORT).show();
					finish();
					startActivity(getIntent());
				}				
			});
		}catch(Exception e){
			Toast.makeText(this,e.getMessage()+"",Toast.LENGTH_LONG).show();
		}
		dialog.show();
	}
	public void addMeans(String name){
		String idlanguage = new AdminDAO(this).getIdLang();
		String words = getStringFromAsset("words.txt");
		String means = getStringFromAsset(name);
		if(means.equals("")){

		}else{
			try{
				new MeansDAO(this).addMeansToWords(words,means,",",idlanguage);
				}catch(Exception e){
					Toast.makeText(MainActivity.this,e.getMessage()+"",Toast.LENGTH_LONG).show();
				}
		}
	}
	public void addWords(){
		String idlanguage = new AdminDAO(this).getIdLang();
		String words = getStringFromAsset("words.txt");
		String spellings = getStringFromAsset("spellings.txt");
		if(spellings.equals("")){

		}else{
			try{
				//new AddWord().execute();
			}catch(Exception e){
				Toast.makeText(MainActivity.this,e.getMessage()+"",Toast.LENGTH_LONG).show();
			}
		}
	}
	public String getStringFromAsset(String filename){
		StringBuilder s = new StringBuilder();
		BufferedReader b = null;
		try{
			b = new BufferedReader(new InputStreamReader(getAssets().open(filename)));
			String mLine;
			while((mLine=b.readLine())!=null){
				s.append(mLine);
			}
		}catch(Exception e){

		}finally{
			try{
				if(b!=null){
					b.close();
				}
			}catch(Exception e){

			}
			return s.toString();
		}
	}
	
	
	private class Data extends AsyncTask<Void, Void, Void>
	{

		@Override
		protected void onPreExecute()
		{		
			// TODO: Implement this method
			super.onPreExecute();
			showProgressDialog();

		}

		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			try{
				list = new WordDAO(MainActivity.this).getFullWord(MainActivity.this);
				}catch(Exception e){}
			return null;
		}
		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			try{
			adapter = new WordAdapter(MainActivity.this,list);
			listWords.setAdapter(adapter);
			dismissProgressDialog();	
			}catch(Exception e){}
		}


	}
	
}
