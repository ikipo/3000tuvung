package com.nhung.threethousand.Database;
import android.content.Context;
import com.nhung.threethousand.Entities.*;
import android.database.sqlite.*;
import android.content.*;
import java.util.*;
import android.database.*;

public class WordDAO extends Database
{
	public WordDAO(Context c){
		super (c);
	}
	
	public void addWord (Word w){
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues ();
		values.put ("id",w.getId());
		values.put ("spelling",w.getSpelling());
		values.put ("audio",w.getAudio());
		db.insert("Word",null,values);
		db.close();
	}
	public boolean checkTabledata(){
		boolean b = false;
		try{
			List<Word> l = getAll();
			if(l.size()>0){
				b = true;
			}
		}catch(Exception e){
			b = false;
		}
		return b;
	}
	public boolean addWordsByIdAndSpelling(String s, String s2, String splitBy){
		//Word w;
		boolean b = false;
		String [] list = s.split(splitBy);
		String [] list2 = s2.split(splitBy);
		if(list.length==list2.length){
			SQLiteDatabase db = getWritableDatabase();
			ContentValues values = new ContentValues ();	
			db.insert("Word",null,values);
			String id,spelling;
			for (int i = 0; i < list.length; i++){
				id = list[i].trim()+"";
				spelling = list2[i].trim()+"";
				//w = new Word (id,spelling);
				values.put("id",id);
				values.put ("spelling",spelling);
				db.insert("Word",null,values);
			}
			db.close();
			b = true;
		}else{
			b = false;
		}	
		return b;
	}
	public void addWordById (String s, String splitBy){
		//Word w;
		String [] list = s.split(splitBy);
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues ();	
		db.insert("Word",null,values);
		String id;
		for (int i = 0; i < list.length; i++){
			id = list[i].trim()+"";
			//w = new Word (id);
			values.put("id",id);
			db.insert("Word",null,values);
		}
		db.close();
	}
	public void addAudioToWord (String id, String audio){
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues ();
		values.put ("audio",audio);
		db.update("Word",values,"id like '"+id+"'",null);
		db.close();
	}
	public List <Word> getListBySql (String sql){
		List <Word> list = new ArrayList <>();
		SQLiteDatabase db = getReadableDatabase();
		//String sql = "";
		Cursor c = db.rawQuery(sql,null);
		if (c!=null){
			c.moveToFirst();
			Word w;
			do{
				String id = c.getString (0);
				String spelling = c.getString(1);
				String audio = c.getString (2);
				w = new Word(id,spelling,audio);
				list.add(w);
			}while(c.moveToNext());
		}
		db.close();
		return list;
	}
	public Word getWordBySql (String sql){
		Word word = new Word();
		SQLiteDatabase db = getReadableDatabase();
		//String sql = "";
		Cursor c = db.rawQuery(sql,null);
		if (c!=null){
			c.moveToFirst();
			do{
				String id = c.getString (0);
				String spelling = c.getString(1);
				String audio = c.getString (2);
				word = new Word(id,spelling,audio);
			}while(c.moveToNext());
		}
		db.close();
		return word;
	}
	public List <Word> getAll (){
		return getListBySql("SELECT * FROM Word");
	}
	
	public boolean checkWord (String id){
		boolean b = false;
		List <Word> list = getAll();
		for (int i = 0; i < list.size(); i++){
			String idWord = list.get(i).getId();
			if(idWord.equals(id)){
				b = true;
			}
		}
		return b;
	}
	public List <FullWord> getFullWord(Context c){
		FullWord f = new FullWord();
		Means m;
		Word w;
		List <FullWord> listFull = new ArrayList <>();
		String idlanguage = new AdminDAO(c).getIdLang();
		List <Word> listWords = getAll();
		List <Means> listMeans = new MeansDAO(c).getListBySql("select * from Means where idLanguage like '"+idlanguage+"'");
		for(int i = 0; i < listMeans.size(); i++){
			m = listMeans.get(i);
			for(int j = 0; j < listWords.size(); j++){
				w = listWords.get(j);
				if(m.getIdWord().equals(w.getId())){
					f = new FullWord(w.getId(),w.getSpelling(),m.getContent(),w.getAudio());
					listFull.add(f);
				}
			}
		}
		return listFull;	
	}
	public List <FullWord> getBookmark(Context c){
		List <Bookmark> bookmarklist = new BookmarkDAO(c).getAll();
		FullWord f = new FullWord();
		Means m;
		Word w;
		String idlanguage = new AdminDAO(c).getIdLang();
		List <Word> listWords = new ArrayList <>();
		List <Means> listMeans = new MeansDAO(c).getListBySql("select * from Means where idLanguage like '"+idlanguage+"'");
		List <FullWord> listFull = new ArrayList <>();
	    for(int i=0;i <bookmarklist.size(); i++){
			try{
				w = getWordBySql("select * from Word where id like '"+bookmarklist.get(i).getIdWord()+"'");
				listWords.add(w);
			}catch(Exception e){
				
			}
		}	
		for(int i = 0; i < listWords.size(); i++){
			w = listWords.get(i);
			for(int j = 0; j < listMeans.size(); j++){
				m = listMeans.get(j);
				if(m.getIdWord().equals(w.getId())){
					f = new FullWord(w.getId(),w.getSpelling(),m.getContent(),w.getAudio());
					listFull.add(f);
				}
			}
		}
		return listFull;
	}
}
