package com.nhung.threethousand.Entities;
import java.io.*;

public class Avatar implements Serializable
{
	private int id;
	private int idWord;
	private String src;

	public Avatar(int id, int idWord, String src)
	{
		this.id = id;
		this.idWord = idWord;
		this.src = src;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getId()
	{
		return id;
	}

	public void setIdWord(int idWord)
	{
		this.idWord = idWord;
	}

	public int getIdWord()
	{
		return idWord;
	}

	public void setSrc(String src)
	{
		this.src = src;
	}

	public String getSrc()
	{
		return src;
	}
	
}
