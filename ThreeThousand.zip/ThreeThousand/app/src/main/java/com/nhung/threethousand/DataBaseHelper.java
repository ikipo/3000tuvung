package com.nhung.threethousand;
import android.database.sqlite.SQLiteOpenHelper;
import java.lang.Override;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import java.io.File;
import java.io.IOException;
import java.lang.Error;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import android.util.Log;
import android.database.SQLException;

 public class DataBaseHelper extends SQLiteOpenHelper {
 
 public static String TAG = "DataBaseHelper";
	public static String DB_NAME = "threethousanddatabase.db";
 public static int VERSION = 1;
 private File DB_FILE;
 private SQLiteDatabase mDataBase;
 private final Context mContext;
 
 public DataBaseHelper (Context context) {
 super(context,DB_NAME,null,VERSION);
 DB_FILE = context.getDatabasePath(DB_NAME);
 this.mContext = context;
 }
 
 @Override
 public void onCreate(SQLiteDatabase db) {
 
 }
 
 @Override
 public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion ){
 
 }
 
 public void createDataBase() throws IOException {
     boolean mDataBaseExist = checkDataBase ();
     if (!mDataBaseExist){
         this.getReadableDatabase();
         this.close();
         try {
         copyDataBase();
         Log.e(TAG,"createDataBase database created");
         }catch (IOException e){
          throw new Error("ErroCopyingDataBase");
         }
     }
 }
 
 public boolean checkDataBase (){
 return DB_FILE.exists();
 }
 
 private void copyDataBase() throws IOException{
     InputStream mInput = mContext.getAssets().open (DB_NAME);
     OutputStream mOutput = new FileOutputStream(DB_FILE);
     byte[] mBuffer = new byte [1024];
     int mLength;
     while ((mLength=mInput.read(mBuffer))>0){
     mOutput.write(mBuffer,0,mLength);
     }
     mOutput.flush();
     mOutput.close();
     mInput.close();
 }
 
 public boolean openDataBase() throws SQLException{
 mDataBase = SQLiteDatabase.openDatabase(DB_FILE.getAbsolutePath(),null,SQLiteDatabase.CREATE_IF_NECESSARY);
 return mDataBase!=null;
 }
 
 @Override
 public synchronized void close (){
     if (mDataBase!=null){
     mDataBase.close();
     }
     super.close();
 }
 }
