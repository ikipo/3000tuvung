package com.nhung.threethousand.Database;
import java.io.*;
import java.nio.channels.*;
import android.os.*;

public class FileUtils
{
	public FileUtils(){}
	
	public static void copyFile(FileInputStream fromFile, FileInputStream toFile) throws IOException{
		FileChannel fromChanel = null;
		FileChannel toChanel = null;
		try{
			fromChanel = fromFile.getChannel();
			toChanel = toFile.getChannel();
			fromChanel.transferTo(0,fromChanel.size(),toChanel);
		}finally{
			try{
				if(fromChanel!=null){
					fromChanel.close();
				}
			}finally{
				if(toChanel!=null){
					toChanel.close();
				}
			}
		}
	}
	
	public void exportDb(){
		try{
			File sd = Environment.getExternalStorageDirectory();
			File data = Environment.getDataDirectory();
			if(sd.canWrite()){
				String currentDbPath = "//data//com.nhung.threethousand//databases//threethousanddatabase.db";
				String backupDbPath = "threethousanddatabase.db";
				File currentDbFile = new File(data,currentDbPath);
				File backupDbFile = new File(sd,backupDbPath);
				if(currentDbFile.exists()){
					FileChannel src = new FileInputStream(currentDbFile).getChannel();
					FileChannel dst = new FileOutputStream(backupDbFile).getChannel();
					dst.transferFrom(src,0,src.size());
					src.close();
					dst.close();
				}
			}
		}catch(Exception e){
			
		}
	}
}
