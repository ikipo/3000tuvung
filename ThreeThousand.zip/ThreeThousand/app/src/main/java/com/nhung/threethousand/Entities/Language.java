package com.nhung.threethousand.Entities;
import java.io.*;

public class Language implements Serializable
{
	private String id;
	private String avatar;

	public Language(String id, String avatar)
	{
		this.id = id;
		this.avatar = avatar;
	}

	public void setAvatar(String avatar)
	{
		this.avatar = avatar;
	}

	public String getAvatar()
	{
		return avatar;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getId()
	{
		return id;
	}
}
