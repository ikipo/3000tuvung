package com.nhung.threethousand.Database;
import android.content.*;
import android.database.sqlite.*;
import android.database.*;
import com.nhung.threethousand.*;

public class AdminDAO extends Database{
	DataAdapter data;
	Context cx;
	public AdminDAO(Context c){
		super(c);
		this.cx = c;
		data = new DataAdapter(cx);
	}
	public void add(){
		data.createDatabase();
		data.open();
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("id","admin");
		values.put("password","123");
		values.put("idlanguage","vn");
		data.insertData("Admin",values);
		db.close();
		data.close();
	}
	public String getIdLang(){
		data.createDatabase();
		data.open();
		String s = "";
		//SQLiteDatabase db = getReadableDatabase();
		String sql = "select * from Admin";
		Cursor c = data.getDataBySql(sql);
		//db.rawQuery(sql,null);
		if(c!=null){
			c.moveToFirst();
			do{
				String id = c.getString(0);
				String password = c.getString(1);
				String idlanguage = c.getString(2);
				s = idlanguage;
			}while(c.moveToNext());
		}data.close();
		return s;
	}
	public void setLanguage(String idlanguage){
		data.createDatabase();
		data.open();
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("idlanguage",idlanguage);
		data.updateData("Admin",values,"id like 'admin'");
		db.close();
		data.close();
	}
}
