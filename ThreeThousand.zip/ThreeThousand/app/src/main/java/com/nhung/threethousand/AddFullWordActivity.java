package com.nhung.threethousand;
import android.app.*;
import android.os.*;
import android.widget.*;
import java.util.*;
import com.nhung.threethousand.Database.*;
import android.view.*;
import android.widget.AdapterView.*;
import com.nhung.threethousand.Entities.*;

public class AddFullWordActivity extends Activity
{
	private String language;
	Button btnAddWords,btnAddWord;
	EditText edtIds,edtSpellings,edtMeanss,edtSplitBy,edtId,edtSpelling,edtMeans;
	Spinner spnLanguage;
	ArrayAdapter <String> adapter;
	public void onCreate(Bundle saveInstanceState){
		super.onCreate(saveInstanceState);
		setContentView(R.layout.addfullword);
		edtIds = (EditText)findViewById(R.id.addfullwordEditText);
		edtSpellings = (EditText)findViewById(R.id.addfullwordEditText2);
		edtMeanss = (EditText)findViewById(R.id.addfullwordEditText3);
		edtSplitBy = (EditText)findViewById(R.id.addfullwordEditText4);
		edtId = (EditText)findViewById(R.id.addfullwordEditText5);
		edtSpelling = (EditText)findViewById(R.id.addfullwordEditText6);
		edtMeans = (EditText)findViewById(R.id.addfullwordEditText7);
		spnLanguage = (Spinner)findViewById(R.id.addfullwordSpinner);
		btnAddWords = (Button)findViewById(R.id.addfullwordButton);
		btnAddWord = (Button)findViewById(R.id.addfullwordButton2);
		language = "";
		showSpinner();
		btnAddWords.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				addWords();
			}
		});
	}
	public void showSpinner(){
		try{
			List<String> list = new LanguageDAO(this).getAllId();
			adapter = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_dropdown_item_1line,list);
			spnLanguage.setAdapter(adapter);
			spnLanguage.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
					public void onItemSelected(AdapterView<?> parent, View view, int position, long id){
						String l = spnLanguage.getSelectedItem().toString();
						setLanguage(l);
						Toast.makeText(getApplicationContext(),language,Toast.LENGTH_SHORT).show();
					}
					public void onNothingSelected(AdapterView<?> parent){

					}
				});
		}catch(Exception e){
			Toast.makeText(this,e.getMessage()+"",Toast.LENGTH_LONG).show();
		}	
	}
	public void addWords(){
		String ids = edtIds.getText().toString()+"";
		String spellings = edtSpellings.getText().toString()+"";
		String means = edtMeanss.getText().toString()+"";
		String splitBy = edtSplitBy.getText().toString()+"";
		String language = getLanguage()+"";
		try{
			WordDAO dao = new WordDAO (this);
			MeansDAO dao2 = new MeansDAO (this);		
			dao.addWordsByIdAndSpelling(ids,spellings,splitBy);
			dao2.addMeansToWords(ids,means,splitBy,language);
			String s1 = ids.split(splitBy).length + "";
			String s2 = spellings.split(splitBy).length + "";
			String s3 = means.split(splitBy).length + "";
			Toast.makeText(getApplicationContext(),s1+" "+s2+" "+s3+"",Toast.LENGTH_LONG).show();
			finish();
		}catch(Exception e){
			Toast.makeText(getApplicationContext(),e.getMessage()+"",Toast.LENGTH_LONG).show();
		}
	}
	public String getLanguage(){
		return language;
	}
	public void setLanguage(String language){
		this.language = language;
	}

	@Override
	protected void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		//adapter.notifyDataSetChanged();
	}
	
	
}
