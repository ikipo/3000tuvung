package com.nhung.threethousand;
import android.app.*;
import android.os.*;
import android.widget.*;
import java.util.*;
import com.nhung.threethousand.Database.*;
import android.view.*;
import android.widget.AdapterView.*;
import com.nhung.threethousand.Entities.*;

public class AddFullWordActivity extends Activity
{
	ProgressDialog progressDialog;
	private String language;
	Button btnAddWords,btnAddWord;
	EditText edtIds,edtSpellings,edtMeanss,edtSplitBy,edtId,edtSpelling,edtMeans;
	Spinner spnLanguage;
	ArrayAdapter <String> adapter;
	public void onCreate(Bundle saveInstanceState){
		super.onCreate(saveInstanceState);
		setContentView(R.layout.addfullword);
		edtIds = (EditText)findViewById(R.id.addfullwordEditText);
		edtSpellings = (EditText)findViewById(R.id.addfullwordEditText2);
		edtMeanss = (EditText)findViewById(R.id.addfullwordEditText3);
		edtSplitBy = (EditText)findViewById(R.id.addfullwordEditText4);
		edtId = (EditText)findViewById(R.id.addfullwordEditText5);
		edtSpelling = (EditText)findViewById(R.id.addfullwordEditText6);
		edtMeans = (EditText)findViewById(R.id.addfullwordEditText7);
		spnLanguage = (Spinner)findViewById(R.id.addfullwordSpinner);
		btnAddWords = (Button)findViewById(R.id.addfullwordButton);
		btnAddWord = (Button)findViewById(R.id.addfullwordButton2);
		language = "";
		showSpinner();
		btnAddWords.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				new Data().execute();
			}
		});
	}
	public void showSpinner(){
		try{
			List<String> list = new LanguageDAO(this).getAllId();
			adapter = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_dropdown_item_1line,list);
			spnLanguage.setAdapter(adapter);
			spnLanguage.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
					public void onItemSelected(AdapterView<?> parent, View view, int position, long id){
						String l = spnLanguage.getSelectedItem().toString();
						setLanguage(l);
						Toast.makeText(getApplicationContext(),language,Toast.LENGTH_SHORT).show();
					}
					public void onNothingSelected(AdapterView<?> parent){

					}
				});
		}catch(Exception e){
			Toast.makeText(this,e.getMessage()+"",Toast.LENGTH_LONG).show();
		}	
	}
	public void addWords(){
		String ids = edtIds.getText().toString()+"";
		String spellings = edtSpellings.getText().toString()+"";
		String means = edtMeanss.getText().toString()+"";
		String splitBy = edtSplitBy.getText().toString()+"";
		String language = getLanguage()+"";
		try{
			WordDAO dao = new WordDAO (this);
			MeansDAO dao2 = new MeansDAO (this);		
			dao.addWordsByIdAndSpelling(ids,spellings,splitBy);
			dao2.addMeansToWords(ids,means,",",splitBy,language);
			String s1 = ids.split(splitBy).length + "";
			String s2 = spellings.split(splitBy).length + "";
			String s3 = means.split(splitBy).length + "";
			Toast.makeText(getApplicationContext(),s1+" "+s2+" "+s3+"",Toast.LENGTH_LONG).show();
			finish();
		}catch(Exception e){
			Toast.makeText(getApplicationContext(),e.getMessage()+"",Toast.LENGTH_LONG).show();
		}
	}
	public void showProgressDialog() {
		if (progressDialog == null) {
			progressDialog = new ProgressDialog(AddFullWordActivity.this);
			progressDialog.setIndeterminate(true);
			progressDialog.setCancelable(false);
		}
		progressDialog.setMessage("Loading ...");
		progressDialog.show();	
	}

	public void dismissProgressDialog() {
		if (progressDialog != null ) {
			progressDialog.dismiss();
		}
	}
	public String getLanguage(){
		return language;
	}
	public void setLanguage(String language){
		this.language = language;
	}

	@Override
	protected void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		//adapter.notifyDataSetChanged();
	}
	public class Data extends AsyncTask<Void,Void,Void>
	{

		@Override
		protected Void doInBackground(Void[] p1)
		{
			addWords();
			// TODO: Implement this method
			return null;
		}


		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			showProgressDialog();
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			dismissProgressDialog();
		}
		
	}
	
}
