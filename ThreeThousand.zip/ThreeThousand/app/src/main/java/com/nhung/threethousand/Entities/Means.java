package com.nhung.threethousand.Entities;
import java.io.*;

public class Means implements Serializable
{
	private int id;
	private String idLanguage;
	private String content,idWord;

	public Means(String idWord, String idLanguage, String content)
	{
		this.idWord = idWord;
		this.idLanguage = idLanguage;
		this.content = content;
	}
	
	public Means (){
		this.id = 0;
		this.idWord = "";
		this.idLanguage = "";
		this.content = "";
	}

	public Means(int id, String idWord, String idLanguage, String content)
	{
		this.id = id;
		this.idWord = idWord;
		this.idLanguage = idLanguage;
		this.content = content;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getId()
	{
		return id;
	}

	public void setIdWord(String idWord)
	{
		this.idWord = idWord;
	}

	public String getIdWord()
	{
		return idWord;
	}

	public void setIdLanguage(String idLanguage)
	{
		this.idLanguage = idLanguage;
	}

	public String getIdLanguage()
	{
		return idLanguage;
	}

	public void setContent(String content)
	{
		this.content = content;
	}

	public String getContent()
	{
		return content;
	}
	
}
