package com.nhung.threethousand;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.*;
import java.io.*;
import com.nhung.threethousand.Database.*;
import java.util.*;

public class AdminActivity extends Activity
{
	String language;
	ProgressDialog progressDialog;
	Spinner sp;
	EditText edtSplit;
	Button btnAddFull,btnAddAudio,btnAddLanguage,btnAddMeans,btnAddAvatar;
	Button btnAddWordsFromAssets,btnAddMeansFromAssets;
	@Override
	public void onCreate (Bundle saveInstanceState){
		super.onCreate(saveInstanceState);
		setContentView(R.layout.admin);
		progressDialog = new ProgressDialog(this);
		sp = (Spinner)findViewById(R.id.adminSpinner);
		edtSplit = (EditText)findViewById(R.id.adminEditText);
		btnAddFull = (Button)findViewById(R.id.btnAddFull);
		btnAddAudio = (Button)findViewById(R.id.btnAddAudio);
		btnAddLanguage = (Button)findViewById(R.id.btnAddLanguage);
		btnAddMeans = (Button)findViewById(R.id.btnAddMeans);
		btnAddAvatar = (Button)findViewById(R.id.btnAddAvatar);
		btnAddWordsFromAssets = (Button)findViewById(R.id.btnAddWordsFromAssets);
		btnAddMeansFromAssets = (Button)findViewById(R.id.btnAddMeansFromAssets);
		try{
			List <String> list = new LanguageDAO(this).getAllId();
			ArrayAdapter <String> adapter = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,list);
			sp.setAdapter(adapter);
			sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
					public void onItemSelected(AdapterView<?> parent, View view, int position, long id){
						String l = sp.getSelectedItem().toString();
						language = l;
						Toast.makeText(getApplicationContext(),language,Toast.LENGTH_SHORT).show();
					}
					public void onNothingSelected(AdapterView<?> parent){

					}
				});
		}catch(Exception e){
			Toast.makeText(this,e.getMessage()+"",Toast.LENGTH_LONG).show();
		}	
		btnAddFull.setOnClickListener(new View.OnClickListener(){
			public void onClick (View v){
				startActivity (new Intent(AdminActivity.this,AddFullWordActivity.class));
			}
			});
		btnAddAudio.setOnClickListener(new View.OnClickListener(){
				public void onClick (View v){
					
				}
			});
		btnAddLanguage.setOnClickListener(new View.OnClickListener(){
				public void onClick (View v){
					startActivity(new Intent(AdminActivity.this,LanguageActivity.class));
				}
			});
		btnAddMeans.setOnClickListener(new View.OnClickListener(){
				public void onClick (View v){

				}
			});
		btnAddAvatar
		.setOnClickListener(new View.OnClickListener(){
				public void onClick (View v){

				}
			});
		btnAddWordsFromAssets.setOnClickListener(new View.OnClickListener(){
				public void onClick (View v){
					//addMeans("means.txt");
					//finish ();
					new AddWord().execute();
				}
			});
		btnAddMeansFromAssets.setOnClickListener(new View.OnClickListener(){
				public void onClick (View v){
					//addMeans("means.txt");
					//finish ();
					String filemeans = language+".txt";
					//addMeans(filemeans);
					String[] param = {filemeans,filemeans};
					Toast.makeText(AdminActivity.this,param [0],Toast.LENGTH_SHORT).show();
					new AddMeans().execute(param);
				}
			});
	}
	
	public String getStringFromAsset(String filename){
		StringBuilder s = new StringBuilder();
		BufferedReader b = null;
		try{
			b = new BufferedReader(new InputStreamReader(getAssets().open(filename)));
			String mLine;
			while((mLine=b.readLine())!=null){
				s.append(mLine);
			}
		}catch(Exception e){
			
		}finally{
			try{
				if(b!=null){
					b.close();
				}
			}catch(Exception e){
				
			}
			return s.toString();
		}
	}

	public void showProgressDialog() {
		if (progressDialog == null) {
			progressDialog = new ProgressDialog(AdminActivity.this);
			progressDialog.setIndeterminate(true);
			progressDialog.setCancelable(false);
		}
		progressDialog.setMessage("Loading ...");
		progressDialog.show();	
	}

	public void dismissProgressDialog() {
		if (progressDialog != null ) {
			progressDialog.dismiss();
		}
	}
	private class AddWord extends AsyncTask<Void, Void, Void>
	{

		@Override
		protected void onPreExecute()
		{		
			// TODO: Implement this method
			super.onPreExecute();
			showProgressDialog();

		}

		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			try{
				addWords2();
			}catch(Exception e){}
			return null;
		}
		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			try{
				finish();
				//startActivity(getIntent());
				dismissProgressDialog();	
			}catch(Exception e){}
		}
		public void addWords2(){
			String idlanguage = new AdminDAO(AdminActivity.this).getIdLang();
			String words = getStringFromAsset("words.txt");
			String spellings = getStringFromAsset("spellings.txt");
			if(spellings.equals("")){

			}else{
				try{
					new WordDAO(AdminActivity.this).addWordsByIdAndSpelling(words,spellings,",");
				}catch(Exception e){
					Toast.makeText(AdminActivity.this,e.getMessage()+"",Toast.LENGTH_LONG).show();
				}
			}
		}
		
		public String getStringFromAsset2(String filename){
			StringBuilder s = new StringBuilder();
			BufferedReader b = null;
			try{
				b = new BufferedReader(new InputStreamReader(getAssets().open(filename)));
				String mLine;
				while((mLine=b.readLine())!=null){
					s.append(mLine);
				}
			}catch(Exception e){

			}finally{
				try{
					if(b!=null){
						b.close();
					}
				}catch(Exception e){

				}
				return s.toString();
			}
		}


	}
	private class AddMeans extends AsyncTask<String, Void, Void>
	{

		@Override
		protected void onPreExecute()
		{		
			// TODO: Implement this method
			super.onPreExecute();
			showProgressDialog();

		}

		@Override
		protected Void doInBackground(String[] p1)
		{
			// TODO: Implement this method
			try{
				addMeans(p1 [0]);
			}catch(Exception e){}
			return null;
		}
		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			try{
				finish();
				//startActivity(getIntent());
				dismissProgressDialog();	
			}catch(Exception e){}
		}
		
		public void addMeans(String name){
			String idlanguage = new AdminDAO(AdminActivity.this).getIdLang();
			String words = getStringFromAsset("words.txt");
			String means = getStringFromAsset(name);
			String splitBy = edtSplit.getText()+"";
			new MeansDAO(AdminActivity.this).addMeansToWords(words,means,",",splitBy,idlanguage);
		}
		public String getStringFromAsset3(String filename){
			StringBuilder s = new StringBuilder();
			BufferedReader b = null;
			try{
				b = new BufferedReader(new InputStreamReader(getAssets().open(filename)));
				String mLine;
				while((mLine=b.readLine())!=null){
					s.append(mLine);
				}
			}catch(Exception e){

			}finally{
				try{
					if(b!=null){
						b.close();
					}
				}catch(Exception e){

				}
				return s.toString();
			}
		}


	}
}
