package com.nhung.threethousand.Entities;
import java.io.*;
import java.util.*;

public class Bookmark implements Serializable
{
	private String idWord;
	private int time;

	public Bookmark(String idWord)
	{
		this.idWord = idWord;
	}

	public Bookmark(String idWord, int time)
	{
		this.idWord = idWord;
		this.time = time;
	}

	public void setIdWord(String idWord)
	{
		this.idWord = idWord;
	}

	public String getIdWord()
	{
		return idWord;
	}

	public void setTime(int time)
	{
		this.time = time;
	}

	public int getTime()
	{
		return time;
	}
}
