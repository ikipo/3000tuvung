package com.nhung.threethousand.Entities;
import java.io.*;

public class Bookmark implements Serializable
{
	private int idWord;
	private int time;

	public Bookmark(int idWord, int time)
	{
		this.idWord = idWord;
		this.time = time;
	}

	public void setIdWord(int idWord)
	{
		this.idWord = idWord;
	}

	public int getIdWord()
	{
		return idWord;
	}

	public void setTime(int time)
	{
		this.time = time;
	}

	public int getTime()
	{
		return time;
	}
}
