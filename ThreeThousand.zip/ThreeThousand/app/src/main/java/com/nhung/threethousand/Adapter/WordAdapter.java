package com.nhung.threethousand.Adapter;
import android.widget.*;
import android.view.*;
import java.util.*;
import com.nhung.threethousand.Entities.*;
import android.content.*;
import com.nhung.threethousand.*;

public class WordAdapter extends BaseAdapter
{
	List <FullWord> list;
	Context c;
	LayoutInflater layoutInflater;
	public WordAdapter(Context c, List <FullWord> list){
		this.c = c;
		this.list = list;
		layoutInflater = LayoutInflater.from(c);
	}

	@Override
	public long getItemId(int p1)
	{
		// TODO: Implement this method
		return p1;
	}

	@Override
	public Object getItem(int p1)
	{
		// TODO: Implement this method
		return list.get(p1);
	}

	@Override
	public int getCount()
	{
		// TODO: Implement this method
		return list.size();
	}

	@Override
	public View getView(int p1, View p2, ViewGroup p3)
	{
		OneItem oneItem;
		// TODO: Implement this method
		if(p2==null){
			p2 = layoutInflater.inflate(R.layout.oneitem,p3,false);
			oneItem = new OneItem();
			oneItem.word = (TextView)p2.findViewById(R.id.idword);
			oneItem.spelling = (TextView)p2.findViewById(R.id.spelling);
			oneItem.means = (TextView)p2.findViewById(R.id.means);
			p2.setTag(oneItem);
		}else{
			oneItem = (OneItem)p2.getTag();
		}
		FullWord f = list.get(p1);
		oneItem.word.setText(f.getId()+"");
		oneItem.spelling.setText(f.getSpelling()+"");
		oneItem.means.setText(f.getMeans()+"");
		return p2;
	}
	
	public class OneItem {
		TextView word,spelling,means;	
	}
	
}
