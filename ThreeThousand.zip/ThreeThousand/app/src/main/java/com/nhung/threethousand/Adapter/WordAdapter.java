package com.nhung.threethousand.Adapter;
import android.widget.*;
import android.view.*;
import java.util.*;
import com.nhung.threethousand.Entities.*;
import android.content.*;
import com.nhung.threethousand.*;
import android.content.res.*;
import android.media.*;
import com.nhung.threethousand.Database.*;

public class WordAdapter extends BaseAdapter
{
	List <FullWord> list;
	Context c;
	LayoutInflater layoutInflater;
	public WordAdapter(Context c, List <FullWord> list){
		this.c = c;
		this.list = list;
		layoutInflater = LayoutInflater.from(c);
	}

	@Override
	public long getItemId(int p1)
	{
		// TODO: Implement this method
		return p1;
	}

	@Override
	public Object getItem(int p1)
	{
		// TODO: Implement this method
		return list.get(p1);
	}

	@Override
	public int getCount()
	{
		// TODO: Implement this method
		return list.size();
	}

	@Override
	public View getView(int p1, View p2, ViewGroup p3)
	{
		final OneItem oneItem;
		// TODO: Implement this method
		if(p2==null){
			p2 = layoutInflater.inflate(R.layout.oneitem,p3,false);
			oneItem = new OneItem();
			oneItem.word = (TextView)p2.findViewById(R.id.idword);
			oneItem.spelling = (TextView)p2.findViewById(R.id.spelling);
			oneItem.means = (TextView)p2.findViewById(R.id.means);
			oneItem.imageView = (ImageView)p2.findViewById(R.id.oneitemImageView);
			oneItem.l = (LinearLayout)p2.findViewById(R.id.oneitemLinearLayout);
			p2.setTag(oneItem);
		}else{
			oneItem = (OneItem)p2.getTag();
		}
		final FullWord f = list.get(p1);
		oneItem.word.setText(f.getId()+"");
		oneItem.spelling.setText(f.getSpelling()+"");
		oneItem.means.setText(f.getMeans()+"");		
		final boolean checkBookmark;
		try{
			new BookmarkDAO(c).remove(new Bookmark("default"));
			checkBookmark = new BookmarkDAO(c).checkBookmark(f.getId());
			//checkBookmark = false;
		}catch(Exception e){
			checkBookmark = false;
		}
		if(checkBookmark){
			oneItem.imageView.setImageDrawable(c.getResources().getDrawable(R.drawable.star_checked));
		}else{
			oneItem.imageView.setImageDrawable(c.getResources().getDrawable(R.drawable.star));
		}
		oneItem.l.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					String name = f.getId();
					playBeep(name);
				}
			});
		oneItem.imageView.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					try {
						if(checkBookmark){				
							oneItem.imageView.setImageDrawable(c.getResources().getDrawable(R.drawable.star));			
							Bookmark b = new Bookmark(f.getId());
							new BookmarkDAO(c).remove(b);
							Toast.makeText(c,"Remove "+b.getIdWord(),Toast.LENGTH_SHORT).show();
						}else{
							oneItem.imageView.setImageDrawable(c.getResources().getDrawable(R.drawable.star_checked));
							Bookmark b = new Bookmark(f.getId());
							new BookmarkDAO(c).add(b);
							Toast.makeText(c,"Added "+b.getIdWord()+" to Bookmark",Toast.LENGTH_SHORT).show();
						}					
					}catch(Exception e){
						Toast.makeText(c,e.getMessage()+"",Toast.LENGTH_SHORT).show();
					}
				}
			});
			return p2;
	}
	public void playBeep(String name) {
		try {
			MediaPlayer m = new MediaPlayer();
			if (m.isPlaying()) {
				m.stop();
				m.release();
				m = new MediaPlayer();
			}

			AssetFileDescriptor descriptor = c.getAssets().openFd(name+".mp3");
			m.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
			descriptor.close();

			m.prepare();
			m.setVolume(1f, 1f);
			m.setLooping(false);
			m.start();
		} catch (Exception e) {
			Toast.makeText(c,e.getMessage()+"",Toast.LENGTH_LONG).show();
		}
	}
	public class OneItem {
		TextView word,spelling,means;	
		ImageView imageView;
		LinearLayout l;
	}
	
}
