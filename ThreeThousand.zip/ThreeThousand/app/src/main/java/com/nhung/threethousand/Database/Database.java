package com.nhung.threethousand.Database;
import android.database.sqlite.*;
import android.content.Context;
import android.database.*;

public class Database extends SQLiteOpenHelper
{

	public Database(Context c)
	{
		super (c,"threethousanddatabase.db",null,1);
	}	

	@Override
	public void onCreate(SQLiteDatabase db)
	{
		// TODO: Implement this method
    	String sql = "CREATE TABLE Word (id text primary key,"								
										+"spelling text,"
										+"audio text"
										+")";
		db.execSQL(sql);	
		sql = "CREATE TABLE Means (id integer primary key autoincrement,"
								  +"idWord integer,"
								  +"idLanguage text,"
								  +"content text"
								  +")";
		db.execSQL(sql);
		sql = "CREATE TABLE Language (id text primary key,"
									 +"avatar text"
									 +")";
		db.execSQL(sql);
		sql = "CREATE TABLE History (id integer primary key autoincrement,"
									+"idWord integer,"
									+"time integer"
									+")";
		db.execSQL(sql);
		sql = "CREATE TABLE Bookmark(idWord text primary key,"
									+"time integer"
									+")";
		db.execSQL(sql);
		sql = "CREATE TABLE Avatar (id integer primary key autoincrement,"
								   +"idWord integer,"
								   +"src text"
								   +")";
		db.execSQL(sql);
		sql = "CREATE TABLE Admin(id text primary key, password text, idlanguage text)";
		db.execSQL(sql);	
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase p1, int p2, int p3)
	{
		// TODO: Implement this method
	}
	
	
	
}
