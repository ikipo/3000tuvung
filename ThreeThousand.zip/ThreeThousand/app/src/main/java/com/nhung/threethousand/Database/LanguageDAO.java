package com.nhung.threethousand.Database;
import android.content.*;
import com.nhung.threethousand.Entities.*;
import android.database.sqlite.*;
import android.database.*;
import java.util.*;
import com.nhung.threethousand.*;

public class LanguageDAO extends Database
{
	DataAdapter data;
	Context cx;
	public LanguageDAO(Context c){
		super(c);
		this.cx = c;
		data = new DataAdapter(c);
	}
	public void add(Language l){
		data.createDatabase();
		data.open();
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("id",l.getId());
		values.put("avatar",l.getAvatar());
		//db.insert("Language",null,values);
		data.insertData("Language",values);
		data.close();
		db.close();
	}
	public List <Language> getListBySql(String sql){
		data.createDatabase();
		data.open();
		List <Language> list = new ArrayList <>();
		SQLiteDatabase db = getReadableDatabase();
		Cursor c = data.getDataBySql(sql);
		//db.rawQuery(sql,null);
		if(c!=null){
			Language l;
			c.moveToFirst();
			do{
				String id = c.getString(0);
				String avatar = c.getString(1);
				l = new Language(id,avatar);
				list.add(l);
			}while(c.moveToNext());
		}data.close();
		return list;
	}
	public List <Language> getAll(){
		return getListBySql("select * from Language");
	}
	public List <String> getAllId(){
		List <String> l = new ArrayList <>();
		List <Language> list2 = getAll();
		for(int i=0; i <list2.size(); i++){
			String id = list2.get(i).getId();
			l.add(id);
		}
		List <String> list = new ArrayList <>();
		for(int i = (l.size()-1); i>=0; i--){
			list.add(l.get(i));
		}
		return list;
	}
}
