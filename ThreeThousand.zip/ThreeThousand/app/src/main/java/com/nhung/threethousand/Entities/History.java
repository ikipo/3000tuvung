package com.nhung.threethousand.Entities;
import java.io.*;

public class History implements Serializable
{
	private int id;
	private int idWord;
	private int time;

	public History(int id, int idWord, int time)
	{
		this.id = id;
		this.idWord = idWord;
		this.time = time;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getId()
	{
		return id;
	}

	public void setIdWord(int idWord)
	{
		this.idWord = idWord;
	}

	public int getIdWord()
	{
		return idWord;
	}

	public void setTime(int time)
	{
		this.time = time;
	}

	public int getTime()
	{
		return time;
	}
}
