package com.nhung.threethousand.Database;
import android.content.*;
import com.nhung.threethousand.Entities.*;
import android.database.sqlite.*;
import android.database.*;
import java.util.*;
import com.nhung.threethousand.*;

public class MeansDAO extends Database
{
	DataAdapter data;
	Context c;
	public MeansDAO (Context c){		
		super (c);
		this.c = c;
		data = new DataAdapter(c);
		addDemo();
	}
	public void addMeansToWord2 (Means m){
		data.createDatabase();
		data.open();
		WordDAO dao = new WordDAO (c);
		boolean checkWord = true;// dao.checkWord(m.getIdWord());
		if(checkWord){
			if(true){
				SQLiteDatabase db = getWritableDatabase();
				ContentValues values = new ContentValues ();
				values.put ("idWord",m.getIdWord());
				values.put ("idLanguage",m.getIdLanguage());
				values.put ("content",m.getContent());
				data.insertData("Means2",values);
				db.close();
				data.close();
			}	
		}		
	}
	
	public void addMeansToWord (Means m){
		data.createDatabase();
		data.open();
		WordDAO dao = new WordDAO (c);
		boolean checkWord = dao.checkWord(m.getIdWord());
		if(checkWord){
			if(checkMeans(m)==false){
				SQLiteDatabase db = getWritableDatabase();
				ContentValues values = new ContentValues ();
				values.put ("idWord",m.getIdWord());
				values.put ("idLanguage",m.getIdLanguage());
				values.put ("content",m.getContent());
				data.insertData("Means",values);
				db.close();
				data.close();
			}	
		}		
	}
	
	public void addMeansToWords (String idWords, String means, String splitByw,String splitBym, String idLanguage){
		String [] list = idWords.split(splitByw);
		String [] list2 = means.split(splitBym);
		if (list.length==list2.length){
			String idWord;
			String content;
			Means m;
			for(int i =0; i < list.length; i++){
				idWord = list[i].trim();
				content = list2[i].trim();
				m = new Means (idWord,idLanguage,content);
				addMeansToWord(m);
			}
		}
	}
	public boolean checkMeans(Means m){
		boolean b = false;
		List <Means> list = getAll();
		String idWord;
		String content;
		String idLanguage;
		for (int i = 0; i < list.size(); i++){
			idWord = list.get(i).getIdWord();
			idLanguage = list.get(i).getIdLanguage();
			content = list.get(i).getContent();
			if(idWord.equals(m.getIdWord())){
				if(idLanguage.equals(m.getIdLanguage())){
					b = true;
				}
			}
		}
		return b;
	}
	public List <Means> getAll (){
		return getListBySql("Select * from Means");
	}
	public List<Means> getListBySql(String sql){
		data.createDatabase();
		data.open();
		List <Means> list = new ArrayList<>();
		SQLiteDatabase db = getReadableDatabase();
		Cursor c = data.getDataBySql(sql);
		//db.rawQuery(sql,null);
		if(c!=null){
			Means m;
			c.moveToFirst();
			do{
				int id = c.getInt(0);
				String idWord = c.getString(1);
				String idLanguage = c.getString(2);
				String content = c.getString(3);
				m = new Means (id,idWord,idLanguage,content);
				list.add(m);
			}while(c.moveToNext());
		}
		data.close();
		return list;
	}
	public void updateMeansToWord (Means m){
		data.createDatabase();
		data.open();
		int id = m.getId();
		WordDAO dao = new WordDAO (c);
		boolean checkWord = dao.checkWord(m.getIdWord());
		if(checkWord){
			SQLiteDatabase db = getWritableDatabase();
			ContentValues values = new ContentValues ();
			values.put ("idWord",m.getIdWord());
			values.put ("idLanguage",m.getIdLanguage());
			values.put ("content",m.getContent());
			data.updateData("Means",values,"id like '"+id+"'");
			db.close();
			data.close();
		}		
	}
	public void addDemo(){
		data.createDatabase();
		data.open();
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put ("idWord","0");
		values.put ("id",0);
		data.insertData("Means",values);
		db.close();
		data.close();
	}
}
