package com.nhung.threethousand;

import android.app.*;
import android.os.*;
import android.content.Context;
import android.webkit.*;
import android.widget.*;
import com.nhung.threethousand.Entities.*;
import com.nhung.threethousand.Database.*;
import java.util.*;
import android.view.*;
import android.content.*;
import com.nhung.threethousand.Adapter.*;
import android.content.res.*;
import android.media.*;

public class MainActivity extends Activity 
{
	Button btnAdmin;
	WebView webView;
	List<FullWord> list;
	ListView listWords;
	ProgressDialog progressDialog;
	WordAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		progressDialog = new ProgressDialog(MainActivity.this);
		
//		String url = "file:///android_asset/index.html";
//		webView = new WebView (this);
//		webView.loadUrl(url);
//		webView.getSettings().setJavaScriptEnabled(true);
//		webView.addJavascriptInterface(w,"wordsfromandroid");
//		setContentView(webView);
		/////////////////////////
		Words w = new Words (this);
		listWords = (ListView)findViewById(R.id.listWords);
		btnAdmin = (Button)findViewById(R.id.btnAdmin);			
		new Data().execute();	
		btnAdmin.setOnClickListener(new View.OnClickListener(){
			public void onClick (View v){
				startActivity (new Intent(MainActivity.this,AdminActivity.class));
			}
		});
    }
	public void showProgressDialog() {
		if (progressDialog == null) {
			progressDialog = new ProgressDialog(MainActivity.this);
			progressDialog.setIndeterminate(true);
			progressDialog.setCancelable(false);
		}
		progressDialog.setMessage("Loading ...");
		progressDialog.show();	
	}
	
	public void dismissProgressDialog() {
		if (progressDialog != null ) {
			progressDialog.dismiss();
		}
	}
	public void show(){
		try{
			final List <FullWord> list = new WordDAO(this).getFullWord(this);
			adapter = new WordAdapter(this,list);
			listWords.setAdapter(adapter);
			dismissProgressDialog();
			listWords.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){
				public boolean onItemLongClick(AdapterView <?> p1, View p2, int p3, long p4){
					try {
						FullWord f = (FullWord)p1.getAdapter().getItem(p3);
						Bookmark b = new Bookmark(f.getId());
						new BookmarkDAO(MainActivity.this).add(b);
						Toast.makeText(MainActivity.this,"Added "+b.getIdWord()+" to Bookmark",Toast.LENGTH_SHORT).show();
					}catch(Exception e){
						Toast.makeText(MainActivity.this,e.getMessage()+"",Toast.LENGTH_SHORT).show();
					}
					return true;
				}
			});
			
		}catch(Exception e){
			Toast.makeText(this,e.getMessage().toString(),Toast.LENGTH_LONG).show();
		}
	}
	public void playBeep(String name) {
		try {
			MediaPlayer m = new MediaPlayer();
			if (m.isPlaying()) {
				m.stop();
				m.release();
				m = new MediaPlayer();
			}

			AssetFileDescriptor descriptor = getAssets().openFd(name+".mp3");
			m.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
			descriptor.close();

			m.prepare();
			m.setVolume(1f, 1f);
			m.setLooping(false);
			m.start();
		} catch (Exception e) {
			Toast.makeText(this,e.getMessage()+"",Toast.LENGTH_LONG).show();
		}
	}
	public void demo(){
		try{
			AdminDAO dao = new AdminDAO(this);
			dao.add();
			String s = dao.getIdLang();
			Toast.makeText(this,s+"",Toast.LENGTH_SHORT).show();			
		}catch(Exception e){
			Toast.makeText(this,e.getMessage()+"",Toast.LENGTH_SHORT).show();						
		}
	}
	
	public void showToast (){	
		webView.loadUrl("javascript:sendToAndroid (result)");	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// TODO: Implement this method
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO: Implement this method
		switch (item.getItemId()) {
			case R.id.language:
				showLanguageDialog();
				return true;
			case R.id.bookmark:
				try{				
				String s = new WordDAO(this).getBookmark(this).size()+"";
				Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
				startActivity(new Intent(MainActivity.this,BookmarkActivity.class));
				}catch(Exception e){
					Toast.makeText(this,e.getMessage()+"",Toast.LENGTH_LONG).show();
				} return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
	
	public void showLanguageDialog (){
		demo();
		final Dialog dialog = new Dialog(this);
		dialog.setTitle("Your Language");
		View v = LayoutInflater.from(this).inflate(R.layout.menulanguage,null,false);
		//dialog.setContentView(R.layout.admin);
		dialog.setContentView(v);
		try{			    
			final ListView lv = (ListView)v.findViewById(R.id.menulanguageListView);			
			ArrayAdapter <String> adapter = new ArrayAdapter (this,android.R.layout.simple_list_item_single_choice,new LanguageDAO(this).getAllId());
			lv.setAdapter(adapter);
	 		lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){
				public void onItemClick(AdapterView <?> p1, View p2, int p3, long p4){
					String id = lv.getItemAtPosition(p3).toString();
					new AdminDAO(MainActivity.this).setLanguage(id);
					dialog.dismiss();
					finish();
					startActivity(getIntent());
				}				
			});
		}catch(Exception e){
			Toast.makeText(this,e.getMessage()+"",Toast.LENGTH_LONG).show();
		}
		dialog.show();
	}

	@Override
	protected void onResume()
	{
		// TODO: Im=uy66plement this method
		super.onResume();
		//adapter.notifyDataSetChanged();
	}
	
	public class Words{
		Context c;
		public Words (Context c){
			this.c = c;
		}
		@android.webkit.JavascriptInterface
		public String sendToWeb (){		
			return "Im Android, send to web text is Hello !";
		}
		@android.webkit.JavascriptInterface
		public String webToAndroid (String text){		
			Toast.makeText(c,text,Toast.LENGTH_SHORT).show();	
			return text;
		}
	}
	private class Data extends AsyncTask<Void, Integer, Void>
	{

		@Override
		protected void onPreExecute()
		{		
			// TODO: Implement this method
			super.onPreExecute();
			showProgressDialog();

		}

		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			try{
				list = new WordDAO(MainActivity.this).getFullWord(MainActivity.this);
				}catch(Exception e){}
			return null;
		}

		@Override
		protected void onProgressUpdate(Integer[] values)
		{
			// TODO: Implement this method
			super.onProgressUpdate(values);
			//pro
			progressDialog.setMessage(values[0]+"%");
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			try{
			adapter = new WordAdapter(MainActivity.this,list);
			listWords.setAdapter(adapter);
			dismissProgressDialog();	
			}catch(Exception e){}
		}


	}
}
