package com.nhung.threethousand;

import android.app.*;
import android.os.*;
import android.content.Context;
import android.webkit.*;
import android.widget.*;
import com.nhung.threethousand.Entities.*;
import com.nhung.threethousand.Database.*;
import java.util.*;
import android.view.*;
import android.content.*;
import com.nhung.threethousand.Adapter.*;

public class MainActivity extends Activity 
{
	Button btnAdmin;
	WebView webView;
	ListView listWords;
	WordAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
//		String url = "file:///android_asset/index.html";
//		webView = new WebView (this);
//		webView.loadUrl(url);
//		webView.getSettings().setJavaScriptEnabled(true);
//		webView.addJavascriptInterface(w,"wordsfromandroid");
//		setContentView(webView);
		/////////////////////////
		Words w = new Words (this);
		listWords = (ListView)findViewById(R.id.listWords);
		btnAdmin = (Button)findViewById(R.id.btnAdmin);
		show();
		btnAdmin.setOnClickListener(new View.OnClickListener(){
			public void onClick (View v){
				startActivity (new Intent(MainActivity.this,AdminActivity.class));
			}
		});
    }
	
	public void show(){
		try{
			List <FullWord> list = new WordDAO(this).getFullWord(this);
			adapter = new WordAdapter(this,list);
			listWords.setAdapter(adapter);
			
		}catch(Exception e){
			
		}
	}
	
	public void demo(){
		WordDAO dao = new WordDAO(this);
		List <FullWord> list = dao.getFullWord(this);
		Toast.makeText(this,list.size()+"",Toast.LENGTH_SHORT).show();
	}
	
	public void showToast (){	
		webView.loadUrl("javascript:sendToAndroid (result)");	
	}

	@Override
	protected void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		//adapter.notifyDataSetChanged();
	}
	
	public class Words{
		Context c;
		public Words (Context c){
			this.c = c;
		}
		@android.webkit.JavascriptInterface
		public String sendToWeb (){		
			return "Im Android, send to web text is Hello !";
		}
		@android.webkit.JavascriptInterface
		public String webToAndroid (String text){		
			Toast.makeText(c,text,Toast.LENGTH_SHORT).show();	
			return text;
		}
	}
}
