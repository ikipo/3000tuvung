package com.nhung.threethousand.Database;
import android.content.*;
import com.nhung.threethousand.Entities.*;
import android.database.sqlite.*;
import java.util.*;
import android.database.*;

public class BookmarkDAO extends Database
{
	public BookmarkDAO(Context c){
		super(c);
	}
	public void add(Bookmark b){
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		String id = b.getIdWord();
		values.put("idWord",id);
		int time = (int)new Date().getTime();
		values.put("time",time);
		db.insert("Bookmark",null,values);
		db.close();
	}
	
	public List <Bookmark> getAll(){
		List <Bookmark> list = new ArrayList <>();
		try{
			SQLiteDatabase db = getReadableDatabase();
			String sql = "select * from Bookmark";
			Cursor c = db.rawQuery(sql,null);
			if(c!=null){
				Bookmark b;
				c.moveToFirst();
				do{
					String idWord = c.getString(0);
					int time = c.getInt(1);
					b = new Bookmark(idWord,time);
					list.add(b);
				}while(c.moveToNext());
			}
			db.close();
		}catch(Exception e){
			
		}
		
		return list;
	}
	public boolean checkBookmark(String idWord){
		boolean b = false;
		try{
			List<Bookmark> list = getAll();
			for(int i=0;i <list.size();i++){
				String idbook = list.get(i).getIdWord();
				if(idbook.equals(idWord)){
					b = true;
				}
			}
		}catch(Exception e){
			b = false;
		}	
		return b;
	}
	public void remove(Bookmark b){
		String id = b.getIdWord();
		SQLiteDatabase db = getWritableDatabase();
		db.delete("Bookmark","idWord like '"+id+"'",null);
		db.close();
	}
}
