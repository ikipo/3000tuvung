package com.nhung.threethousand.Database;
import android.content.*;
import com.nhung.threethousand.Entities.*;
import android.database.sqlite.*;
import java.util.*;
import android.database.*;
import com.nhung.threethousand.*;

public class BookmarkDAO extends Database
{
	DataAdapter data;
	Context cx;
	public BookmarkDAO(Context c){
		super(c);
		this.cx = c;
		data = new DataAdapter(cx);
	}
	public void add(Bookmark b){
		data.createDatabase();
		data.open();
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		String id = b.getIdWord();
		values.put("idWord",id);
		int time = (int)new Date().getTime();
		values.put("time",time);
		data.insertData("Bookmark",values);
		db.close();
		data.close();
	}
	
	public List <Bookmark> getAll(){
		data.createDatabase();
		data.open();
		List <Bookmark> list = new ArrayList <>();
		try{
			SQLiteDatabase db = getReadableDatabase();
			String sql = "select * from Bookmark";
			Cursor c = data.getDataBySql(sql);
			// db.rawQuery(sql,null);
			if(c!=null){
				Bookmark b;
				c.moveToFirst();
				do{
					String idWord = c.getString(0);
					int time = c.getInt(1);
					b = new Bookmark(idWord,time);
					list.add(b);
				}while(c.moveToNext());
			}
			db.close();
			data.close();
		}catch(Exception e){
			
		}
		
		return list;
	}
	public boolean checkTabledata(){
		boolean b = false;
		try{
			List<Bookmark> l = getAll();
			if(l.size()>0){
				b = true;
			}
		}catch(Exception e){
			b = false;
		}
		return b;
	}
	public boolean checkBookmark(String idWord){
		boolean b = false;
		try{
			List<Bookmark> list = getAll();
			for(int i=0;i <list.size();i++){
				String idbook = list.get(i).getIdWord();
				if(idbook.equals(idWord)){
					b = true;
				}
			}
		}catch(Exception e){
			b = false;
		}	
		return b;
	}
	public void remove(Bookmark b){
		data.createDatabase();
		data.open();
		String id = b.getIdWord();
		SQLiteDatabase db = getWritableDatabase();
		data.delete("Bookmark","idWord like '"+id+"'");
		db.close();
		data.close();
	}	
}
