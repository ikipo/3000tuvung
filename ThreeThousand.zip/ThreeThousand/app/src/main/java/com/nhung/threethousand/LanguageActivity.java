package com.nhung.threethousand;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import com.nhung.threethousand.Entities.*;
import com.nhung.threethousand.Database.*;
import java.util.*;

public class LanguageActivity extends Activity
{
	EditText edtId, edtAvatar;
	ListView listView;
	Button btnAdd;
	ArrayAdapter<String> adapter;
	public void onCreate(Bundle saveInstanceState){
		super.onCreate(saveInstanceState);
		setContentView(R.layout.language);
		edtId = (EditText)findViewById(R.id.languageEditText);
		edtAvatar = (EditText)findViewById(R.id.languageEditText2);
		btnAdd = (Button)findViewById(R.id.languageButton);
		listView = (ListView)findViewById(R.id.listVew);
		try{
			List <String> list = new LanguageDAO(this).getAllId();
			adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_single_choice,list);
			listView.setAdapter(adapter);
		}catch(Exception e){
			Toast.makeText(this,e.getMessage()+"",Toast.LENGTH_LONG).show();
		}	
		btnAdd.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				String id = edtId.getText().toString().trim();
				String avatar = edtAvatar.getText().toString().trim();
				if(id.equals("")){
					Toast.makeText(getApplicationContext(),"nul",Toast.LENGTH_SHORT).show();
				}else{
					Language l = new Language(id,avatar);		
					new LanguageDAO(getApplicationContext()).add(l);
					Toast.makeText(getApplicationContext(),"Added",Toast.LENGTH_SHORT).show();			
					finish ();
					startActivity(getIntent());
				}
			}
			});
	}
}
